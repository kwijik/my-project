<?php

namespace JeuxBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JeuxBundle extends Bundle
{
}
